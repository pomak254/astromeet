// Gerekli modülleri yükle
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

// Uygulamayı başlat
const app = express();
const PORT = process.env.PORT || 3000; // PORT değişkeni ile dinamikleştirildi

// Public klasörünü statik dosyalar için tanımla
app.use(express.static(path.join(__dirname, 'public')));

// POST istekleri için body-parser middleware'i ekle
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Multer dosya yükleme ayarları (profil fotoğrafları için)
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = path.join(__dirname, 'public/uploads');
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
        cb(null, `${file.fieldname}-${uniqueSuffix}-${file.originalname}`);
    }
});
const upload = multer({ storage });

// Ana sayfa rotası
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Profil sayfası rotası
app.get('/profile', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'profile.html'));
});

// Kayıt işlemi rotası
app.post('/register', (req, res) => {
    const { username, email, password, gender, birthdate } = req.body;

    if (!username || !email || !password || !gender || !birthdate) {
        return res.status(400).json({ message: 'Tüm alanlar doldurulmalıdır!' });
    }

    console.log(`Kayıt Olundu: ${username}, ${email}`);
    res.status(200).json({ message: 'Kayıt işlemi başarılı!' });
});

// Giriş işlemi rotası
app.post('/login', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: 'E-posta ve şifre gereklidir!' });
    }

    console.log(`Giriş Yapıldı: ${email}`);
    res.status(200).json({ message: 'Giriş başarılı!' });
});

// Şifremi unuttum rotası
app.post('/forgot-password', (req, res) => {
    const { email } = req.body;

    if (!email) {
        return res.status(400).json({ message: 'E-posta adresi gereklidir!' });
    }

    console.log(`Şifre sıfırlama bağlantısı gönderildi: ${email}`);
    res.status(200).json({ message: 'Şifre sıfırlama bağlantısı gönderildi!' });
});

// Profil fotoğrafı yükleme rotası
app.post('/upload-avatar', upload.single('avatar'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ message: 'Dosya yüklenemedi!' });
    }
    const imagePath = `/uploads/${req.file.filename}`;
    console.log(`Fotoğraf Yüklendi: ${imagePath}`);
    res.status(200).json({ message: 'Fotoğraf başarıyla yüklendi!', path: imagePath });
});

// 404 Hatası için Genel Rota
app.use((req, res) => {
    res.status(404).send('Sayfa bulunamadı!');
});

// Sunucuyu başlat
app.listen(PORT, () => {
    console.log(`Sunucu http://localhost:${PORT} adresinde çalışıyor.`);
});
