const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const session = require('express-session');
const MongoStore = require('connect-mongo'); // MongoDB oturumları için
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const User = require('./models'); // Kullanıcı modeli

const app = express();

// **MongoDB Bağlantısı**
mongoose.connect(
    'mongodb+srv://ysametgokan:124578Sa@cluster0.ryk9b.mongodb.net/AstroMeet',
    { useNewUrlParser: true, useUnifiedTopology: true }
)
    .then(() => console.log('Veritabanına başarıyla bağlandı'))
    .catch(err => console.error('Veritabanı bağlantı hatası:', err));

// **Middleware**
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// **Oturum Yapılandırması**
app.use(
    session({
        secret: 'astromeet-secret-key',
        resave: false,
        saveUninitialized: false,
        store: MongoStore.create({
            mongoUrl: 'mongodb+srv://ysametgokan:124578Sa@cluster0.ryk9b.mongodb.net/AstroMeet',
            collectionName: 'sessions'
        }),
        cookie: {
            maxAge: 600000, // 10 dakika
            httpOnly: true, // Tarayıcıdan erişimi engeller
            secure: false   // HTTPS kullanıyorsanız true yapın
        },
    })
);

// **Multer Ayarları (Fotoğraf Yükleme)**
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = path.join(__dirname, 'public/uploads');
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
        cb(null, `${file.fieldname}-${uniqueSuffix}-${file.originalname}`);
    }
});
const upload = multer({ storage });

// **Kayıt İşlemi**
app.post('/register', async (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ message: 'Tüm alanlar doldurulmalıdır!' });
    }

    try {
        const existingUser = await User.findOne({ $or: [{ username }, { email }] });
        if (existingUser) {
            return res.status(400).json({ message: 'Kullanıcı adı veya e-posta zaten mevcut.' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ username, email, password: hashedPassword });
        await newUser.save();
        res.status(201).json({ message: 'Kayıt başarılı!' });
    } catch (error) {
        console.error('Kayıt hatası:', error);
        res.status(500).json({ message: 'Kayıt başarısız!' });
    }
});

// **Giriş İşlemi**
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: 'E-posta ve şifre gereklidir!' });
    }

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(401).json({ message: 'Kullanıcı bulunamadı!' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Şifre hatalı!' });
        }

        req.session.user = { id: user._id, username: user.username, email: user.email };
        console.log('Giriş yapıldı:', req.session.user); // Oturum bilgilerini logla

        res.redirect('/profile');
    } catch (error) {
        console.error('Giriş hatası:', error);
        res.status(500).json({ message: 'Bir hata oluştu!' });
    }
});

// **Profil Bilgilerini Alma**
app.get('/profile', (req, res) => {
    if (!req.session.user) {
        console.log('Oturum bulunamadı, ana sayfaya yönlendiriliyor.');
        return res.redirect('/');
    }
    console.log('Profil bilgileri:', req.session.user); // Profil bilgilerini logla

    res.json(req.session.user); // Kullanıcı bilgilerini JSON olarak gönder
});

// **Profil Fotoğrafı Yükleme**
app.post('/upload-avatar', upload.single('avatar'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ message: 'Dosya yüklenemedi!' });
    }
    const imagePath = `/uploads/${req.file.filename}`;
    res.status(200).json({ message: 'Fotoğraf yüklendi!', path: imagePath });
});

// **Çıkış İşlemi**
app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) return res.status(500).json({ message: 'Çıkış sırasında hata oluştu.' });
        res.redirect('/');
    });
});

// **Ana Sayfa Yönlendirmesi**
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// **Sunucu Başlatma**
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Sunucu http://localhost:${PORT} adresinde çalışıyor`));
