const mongoose = require('mongoose');
const { Schema } = mongoose;
const bcrypt = require('bcrypt'); // Şifreleme için bcrypt

// Kullanıcı Şeması Tanımı
const userSchema = new Schema({
    username: {
        type: String,
        required: [true, 'Kullanıcı adı gereklidir.'],
        trim: true,
        minlength: [3, 'Kullanıcı adı en az 3 karakter olmalıdır.']
    },
    email: {
        type: String,
        required: [true, 'E-posta adresi gereklidir.'],
        unique: true,
        lowercase: true,
        trim: true,
        match: [/^\S+@\S+\.\S+$/, 'Geçerli bir e-posta adresi girin.']
    },
    password: {
        type: String,
        required: [true, 'Şifre gereklidir.'],
        minlength: [6, 'Şifre en az 6 karakter olmalıdır.']
    },
    bio: {
        type: String, // Kullanıcı biyografisi
        maxlength: 500,
        default: 'Henüz bir biyografi eklenmedi.'
    },
    avatar: {
        type: String, // Avatar URL'si
        default: '/images/avatar-placeholder.png'
    },
    notificationsEnabled: {
        type: Boolean, // Bildirim ayarları
        default: true
    },
    lastLogin: {
        type: Date, // Son giriş tarihi
        default: null
    },
    resetToken: String, // Şifre sıfırlama token’i
    resetTokenExpiration: Date, // Token’in geçerlilik süresi
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// Şifreyi kaydetmeden önce hash'leme işlemi
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next(); // Şifre değişmediyse işlem yapma
    try {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (error) {
        next(error);
    }
});

// Şifreyi doğrulama fonksiyonu
userSchema.methods.comparePassword = async function (candidatePassword) {
    return bcrypt.compare(candidatePassword, this.password);
};

// Bildirim ayarlarını değiştirme fonksiyonu
userSchema.methods.toggleNotifications = async function () {
    this.notificationsEnabled = !this.notificationsEnabled;
    await this.save();
};

// Kullanıcı Modeli Oluşturma
const User = mongoose.model('User', userSchema);

module.exports = User;
